import pygame
import os
import asyncio


def flip(sprites, flip1, flip2):
    return [pygame.transform.flip(sprite, flip1, flip2) for sprite in sprites]

def load_sprite_sheets(dir1, dir2, width, height, direction=False):
    path = os.path.join("assets", dir1, dir2)
    images = [f for f in os.listdir(path) if os.path.isfile(os.path.join(path, f))]

    all_sprites = {}

    for image in images:
        sprite_sheet = pygame.image.load(os.path.join(path, image))
        sprites = []
        for i in range(sprite_sheet.get_width() // width):
            surface = pygame.Surface((width, height), pygame.SRCALPHA, 32)
            rect = pygame.Rect(i * width, 0, width, height)
            surface.blit(sprite_sheet, (0, 0), rect)
            sprites.append(pygame.transform.scale2x(surface))

            all_sprites[image.replace(".png", "")] = sprites

    return all_sprites

class Player(pygame.sprite.Sprite):
    speed = pygame.Vector2(0, 0)
    VEL = 4
    direction = "right"
    mask = None
    animation_count = 0
    ANIMATION_DELAY = 4
    keys = 0
    
    def __init__(self, x, y , width, height, doors):
        self.SPRITES = load_sprite_sheets("MainCharacters", "player", 20, 20, True)
        self.rect = pygame.Rect(x, y, width, height)
        self.maxDoors = doors * 2
        self.startingDoors = doors
        self.doors = doors

    def move(self, dx, dy):
        self.rect.x += dx
        self.rect.y += dy

    def move_left(self):
        if self.direction != "left":
            self.direction = "left"
            self.animation_count = 0
        self.speed.x = -self.VEL

    def move_right(self):
        if self.direction != "right":
            self.direction = "right"
            self.animation_count = 0
        self.speed.x = self.VEL     

    def move_up(self):
        if self.direction != "up":
            self.direction = "up"
            self.animation_count = 0
        self.speed.y = -self.VEL

    def move_down(self):
        if self.direction != "down":
            self.direction = "down"
            self.animation_count = 0
        self.speed.y = self.VEL        

    def createDoor(self):
        if self.doors > 0:
            if self.direction == "left":
                self.move(-block_size, 0)
                for obj in levelLoader.objects:
                    if pygame.sprite.collide_rect(self, obj):
                        levelLoader.objects.remove(obj)
                        obj.kill()
                        id = self.maxDoors - self.doors
                        levelLoader.doors.append(Door(obj.rect.x, obj.rect.y, block_size, False, id, id - self.startingDoors))
                        self.doors -= 1
                        break
                self.move(block_size, 0)
                
            if self.direction == "right":
                self.move(block_size, 0)
                for obj in levelLoader.objects:
                    if pygame.sprite.collide_rect(self, obj):
                        levelLoader.objects.remove(obj)
                        obj.kill()
                        id = self.maxDoors - self.doors
                        levelLoader.doors.append(Door(obj.rect.x, obj.rect.y, block_size, False, id, id - self.startingDoors))
                        self.doors -= 1
                        break
                self.move(-block_size, 0)

            if self.direction == "up":
                self.move(0, -block_size)
                for obj in levelLoader.objects:
                    if pygame.sprite.collide_rect(self, obj):
                        levelLoader.objects.remove(obj)
                        obj.kill()
                        id = self.maxDoors - self.doors
                        levelLoader.doors.append(Door(obj.rect.x, obj.rect.y, block_size, False, id, id - self.startingDoors))
                        self.doors -= 1
                        break
                self.move(0, block_size)
            
            if self.direction == "down":
                self.move(0, block_size)
                for obj in levelLoader.objects:
                    if pygame.sprite.collide_rect(self, obj):
                        levelLoader.objects.remove(obj)
                        obj.kill()
                        id = self.maxDoors - self.doors
                        levelLoader.doors.append(Door(obj.rect.x, obj.rect.y, block_size, False, id, id - self.startingDoors))
                        self.doors -= 1
                        break
                self.move(0, -block_size)

    def lockDoor(self):
        if self.keys > 0:
            if self.direction == "left" and not collide(self, levelLoader.doors, 0,0):
                self.move(-block_size, 0)
                for door in levelLoader.doors:
                    if pygame.sprite.collide_rect(self, door) and not door.locked:
                        door.lock()
                        self.keys -= 1
                        id = door.id
                        for door in levelLoader.doors:
                            if door.id == id - self.startingDoors:
                                door.unlock()
                        break
                    
                self.move(block_size, 0)
                    
            if self.direction == "right" and not collide(self, levelLoader.doors, 0,0):
                self.move(block_size, 0)
                for door in levelLoader.doors:
                    if pygame.sprite.collide_rect(self, door) and not door.locked:
                        door.lock()
                        self.keys -= 1
                        id = door.id
                        for door in levelLoader.doors:
                            if door.id == id - self.startingDoors:
                                door.unlock()
                        break
                self.move(-block_size, 0)   

            if self.direction == "up" and not collide(self, levelLoader.doors, 0, 0):
                self.move(0, -block_size)
                for door in levelLoader.doors:
                    if pygame.sprite.collide_rect(self, door) and not door.locked:
                        door.lock()
                        self.keys -= 1
                        id = door.id
                        for door in levelLoader.doors:
                            if door.id == id - self.startingDoors:
                                door.unlock()
                        break
                    
                self.move(0, block_size)
            
            if self.direction == "down" and not collide(self, levelLoader.doors, 0, 0):
                self.move(0, block_size)
                for door in levelLoader.doors:
                    if pygame.sprite.collide_rect(self, door) and not door.locked:
                        door.lock()
                        self.keys -= 1
                        id = door.id
                        for door in levelLoader.doors:
                            if door.id == id - self.startingDoors:
                                door.unlock()
                        break
                    
                self.move(0, -block_size)

    def update(self):
        self.rect = self.sprite.get_rect(topleft=(self.rect.x, self.rect.y))
        self.mask = pygame.mask.from_surface(self.sprite)
        
    def loop(self):
        self.move(self.speed.x, self.speed.y)
        self.update_sprite()

    def death(self):
        self.rect.x = 100
        self.rect.y = 100
        self.fall_count = 0
        self.jump_count = 1

    def update_sprite(self):
        sprite_sheet = "idle"
        sprite_sheet_name = sprite_sheet + "_" + self.direction
        sprites = self.SPRITES[sprite_sheet_name]
        sprite_index = (self.animation_count //
                        self.ANIMATION_DELAY) % len(sprites)
        self.sprite = sprites[sprite_index]
        self.animation_count += 1
        
    def draw(self, screen):
        screen.blit(self.sprite, (self.rect.x, self.rect.y))



class Platform(pygame.sprite.Sprite):
    def __init__(self, x, y, width, height, name=None):
        super().__init__()
        self.rect = pygame.Rect(x, y, width, height)
        self.image = pygame.Surface((width, height), pygame.SRCALPHA)
        self.width = width
        self.height = height
        self.name = name

    def draw(self, screen):
        screen.blit(self.image, (self.rect.x, self.rect.y))

def get_block(size, img):
    path = os.path.join("assets", "Terrain", img + ".png")
    image = pygame.image.load(path).convert_alpha()
    surface = pygame.Surface((size, size), pygame.SRCALPHA, 32)
    rect = pygame.Rect(0, 0, size, size)
    surface.blit(image, (0, 0))
    return pygame.transform.scale2x(surface)


class Block(Platform):
    def __init__(self, x, y, size):
        super().__init__(x, y, size, size)
        block = get_block(size, "wall")
        self.image.blit(block, (0, 0))
        self.mask = pygame.mask.from_surface(self.image)
    
class Door(Platform):
    def __init__(self, x, y, size, locked, id, coid):
        super().__init__(x, y, size, size)
        self.coid = str(coid)
        block = get_block(size, "unlockedDoor" + self.coid)
        self.size = size
        self.image.blit(block, (0, 0))
        self.mask = pygame.mask.from_surface(self.image)
        self.locked = locked
        self.id = id
    def lock(self):
        block = get_block(self.size, "door" + self.coid)
        self.image.blit(block, (0, 0))
        self.mask = pygame.mask.from_surface(self.image)
        self.locked = True
    def unlock(self):
        block = get_block(self.size, "unlockedDoor" + self.coid)
        self.image.blit(block, (0, 0))
        self.mask = pygame.mask.from_surface(self.image)
        self.locked = False

class Goal(Platform):
    def __init__(self, x, y, size):
        super().__init__(x, y, size, size)
        block = get_block(size, "goal")
        self.image.blit(block, (0, 0))
        self.mask = pygame.mask.from_surface(self.image)

class Key(pygame.sprite.Sprite):
    collected = False
    def __init__(self, x, y, size, name=None):
        super().__init__()
        self.rect = pygame.Rect(x, y, size, size)
        self.image = pygame.Surface((size, size), pygame.SRCALPHA)
        self.width = size
        self.height = size
        self.name = name
        block = get_block(size, "key")
        self.image.blit(block, (0, 0))
        self.mask = pygame.mask.from_surface(self.image)
    def draw(self, screen):
        if not pygame.sprite.collide_rect(self, levelLoader.char) and not self.collected:
            screen.blit(self.image, (self.rect.x, self.rect.y))
        else:
            if self.collected == False:
                levelLoader.char.keys += 1
            self.collected = True
        
def get_button(width, height, img):
    path = os.path.join("assets", "Menu", img + ".png")
    image = pygame.image.load(path).convert_alpha()
    surface = pygame.Surface((width, height), pygame.SRCALPHA, 32)
    rect = pygame.Rect(0, 0, width, height)
    surface.blit(image, (0, 0))
    return pygame.transform.scale2x(surface)
            
class Button(Platform):
    def __init__(self, img, x, y, width, height):
        super().__init__(x, y, width, height)
        block = get_button(width, height, img)
        self.image.blit(block, (0, 0))
        self.mask = pygame.mask.from_surface(self.image)
    def checkForInput(self, position):
        if position[0] in range(self.rect.left, self.rect.right) and position[1] in range(self.rect.top, self.rect.bottom):
            return True
        return False
    def draw(self):
        screen.blit(self.image, (self.rect.x, self.rect.y))

    

def collide(character, objects, speedx, speedy):
    character.move(speedx, speedy)
    character.update()
    collided_object = None
    for obj in objects:
        if pygame.sprite.collide_mask(character, obj):
            collided_object = obj
            break
    for door in levelLoader.doors:
        if pygame.sprite.collide_mask(character, door) and door.locked:
            collided_object = door
            break
    if pygame.sprite.collide_mask(character, levelLoader.goal):
        character.move(-speedx, -speedy)
        levelLoader.nextLevel()
    character.move(-speedx, -speedy)
    character.update()
    return collided_object


def handle_move(character):
    keys = pygame.key.get_pressed()
    character.speed.x = 0
    character.speed.y = 0
    collide_left = collide(character, levelLoader.objects, -character.VEL,0)
    collide_right = collide(character, levelLoader.objects, character.VEL,0)
    collide_up = collide(character, levelLoader.objects, 0,-character.VEL)
    collide_down = collide(character, levelLoader.objects, 0,character.VEL)
    
    if (keys[pygame.K_LEFT] or keys[pygame.K_a]) and not collide_left and not character.rect.left < 1:
            character.move_left()
    elif (keys[pygame.K_RIGHT] or keys[pygame.K_d]) and not collide_right and not character.rect.right > WIDTH:
            character.move_right()
    elif (keys[pygame.K_UP] or keys[pygame.K_w]) and not collide_up and not character.rect.top < 1:
            character.move_up()
    elif (keys[pygame.K_DOWN] or keys[pygame.K_s]) and not collide_down and not character.rect.bottom > HEIGHT:
            character.move_down()

block_size = 50
class levels():
    number = 1
    char = Player(100, 100, 50, 50, 1)
    objects = []
    doors = []
    keys = []
    #goal = Goal(0, 0, block_size)
    def loadlevel1(self):
        self.number = 1
        self.char = Player(100, 100, 50, 50, 1)
        self.coords = [[0,0], [1,0], [2,0], [3,0], [4,0], [5,0], [5,1], [5,2], [5,3], [5,4], [5,5], [0,1], [0,1], [0,2], [0,3], [0,4], [0,5], [0,5], [1,5], [2,5], [3,5], [4,5], [5,5]]
        for i in range(20):
            if not i == 10:
                self.coords.append([i, 8])
        self.doorCoords = [[10,8]]
        self.keyCoords = [[8,5]]
        self.goalCoords = [[10,10]]
        self.levelSetup()
    
    def loadlevel2(self):
        self.number = 2
        self.char = Player(100, 70, 50, 50, 2)
        self.coords = []
        for i in range(20):
            self.coords.append([i,3])
            if not i == 6:
                self.coords.append([i,7])
                self.coords.append([i,8])
        for i in range(12):
            self.coords.append([4,i])
            if not i == 10:
                self.coords.append([8,i])
        self.doorCoords = [[6,7], [8, 10]]
        self.keyCoords = [[6,5], [6, 10]]
        self.goalCoords = [[12,10]]
        self.levelSetup()

    def loadlevel3(self):
        self.number = 3
        self.char = Player(100, 100, 50, 50, 3)
        self.coords = []
        for i in range(20):
            if not i == 10:
                self.coords.append([i,3])
            if not i == 3:
                self.coords.append([i,7])
                self.coords.append([i,8])
        for i in range(12):
            if not i == 10:
                self.coords.append([6,i])
        self.doorCoords = [[10,3], [6, 10], [3, 7]]
        self.keyCoords = [[3,5], [8, 5], [8, 1]]
        self.goalCoords = [[10,10]]
        self.levelSetup()
    
    def loadLevel4(self):
        self.number = 4
        self.char = Player(100, 100, 50, 50, 3)
        self.coords = []
        for i in range(20):
            if not i == 10:
                self.coords.append([i,3])
            if not i == 3:
                self.coords.append([i,7])
                self.coords.append([i,8])
        for i in range(12):
            if not i == 10:
                self.coords.append([6,i])
        self.doorCoords = [[6, 10], [10,3], [3, 7]]
        self.keyCoords = [[3,5], [8, 5], [8, 1]]
        self.goalCoords = [[10,10]]
        self.levelSetup()
    
    def loadLevel5(self):
        self.number = 5
        self.char = Player(100, 100, 50, 50, 3)
        self.coords = []
        for i in range(5, 20):
            self.coords.append([i,3])
            if (not i == 8) and (not i == 18):
                self.coords.append([i,7])
                self.coords.append([i,8])
        for i in range(12):
            self.coords.append([5,i])
            if not i == 5:
                self.coords.append([15,i])
                if i > 3:
                    self.coords.append([16,i])
            if not (i > 3 and i < 7):
                self.coords.append([11,i])
        for i in range(3, 7):
            self.coords.append([6,i])
        self.doorCoords = [[18, 7], [15,5], [8, 7]]
        self.keyCoords = [[8,5], [18, 5], [8, 10]]
        self.goalCoords = [[18,10]]
        self.levelSetup()

    def nextLevel(self):
        if self.number == 1:
            self.loadlevel2()
        elif self.number == 2:
            self.loadlevel3()
        elif self.number == 3:
            self.loadLevel4()
        elif self.number == 4:
            self.loadLevel5()

    def levelSetup(self):
        self.objects = []
        self.doors = []
        self.keys = []
        for i in range(len(self.coords)):
            x = self.coords[i][0] * block_size
            y = self.coords[i][1] * block_size
            self.objects.append(Block(x, y, block_size))

        for i in range(len(self.doorCoords)):
            x = self.doorCoords[i][0] * block_size
            y = self.doorCoords[i][1] * block_size
            self.doors.append(Door(x, y, block_size, True, i, i))
            self.doors[i].lock()

        for i in range(len(self.keyCoords)):
            x = self.keyCoords[i][0] * block_size
            y = self.keyCoords[i][1] * block_size
            self.keys.append(Key(x, y, 96))

        for i in range(len(self.goalCoords)):
            x = self.goalCoords[i][0] * block_size
            y = self.goalCoords[i][1] * block_size
            self.goal = Goal(x, y, block_size)
    
pygame.init()


WIDTH, HEIGHT = 1000, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("my-game")



resume = Button("resume", WIDTH / 2 - 64, 50, 128, 128)
reset = Button("reset", WIDTH / 2 - 64, 150, 128, 128)
levelselect = Button("levelselect", WIDTH / 2 - 64, 300, 128, 128)
quit = Button("quit", WIDTH / 2 - 64, 400, 128, 128)
howToPlay = Button("howToPlay", WIDTH / 2 - 64, 400, 128, 128)
exit = Button("exit", 40, 40, 128, 128)



title = Button("title", WIDTH / 2 - 64, 100, 128, 128)

level1 = Button("level1", 200, 100, 64, 64)
level2 = Button("level2", 300, 100, 64, 64)
level3 = Button("level3", 400, 100, 64, 64)
level4 = Button("level4", 500, 100, 64, 64)
level5 = Button("level5", 600, 100, 64, 64)

levelLoader = levels()

bgPath = os.path.join("assets", "Terrain", "background.png")
bg = pygame.image.load(bgPath).convert_alpha()
async def main():
    clock = pygame.time.Clock()
    running = True
    paused = False
    levelMenu = False
    mainMenu = True
    tutorial = False
    levelLoader.loadlevel1()
    while running:
        
        screen.blit(bg, (0,0))
        MENU_MOUSE_POS = pygame.mouse.get_pos()
        if not tutorial:
            if not mainMenu:
                if not levelMenu:
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                            running = False
                        if event.type == pygame.KEYDOWN and not paused:
                            if event.key == pygame.K_q:
                                paused = True
                            elif event.key == pygame.K_SPACE:
                                levelLoader.char.createDoor()
                            elif event.key == pygame.K_e:
                                levelLoader.char.lockDoor()
                        if event.type == pygame.MOUSEBUTTONDOWN and paused:
                            if resume.checkForInput(MENU_MOUSE_POS):
                                paused = False
                            if reset.checkForInput(MENU_MOUSE_POS):
                                if levelLoader.number == 1:
                                    levelLoader.loadlevel1()
                                    paused = False
                                if levelLoader.number == 2:
                                    levelLoader.loadlevel2()
                                    paused = False
                                if levelLoader.number == 3:
                                    levelLoader.loadlevel3()
                                    paused = False
                                if levelLoader.number == 4:
                                    levelLoader.loadLevel4()
                                    paused = False
                                if levelLoader.number == 5:
                                    levelLoader.loadLevel5()
                                    paused = False
                            if levelselect.checkForInput(MENU_MOUSE_POS):
                                levelMenu = True      
                            if quit.checkForInput(MENU_MOUSE_POS):
                                mainMenu = True
                    
                    
                    for obj in levelLoader.objects:
                        obj.draw(screen)

                    for door in levelLoader.doors:
                        door.draw(screen)

                    for key in levelLoader.keys:
                        key.draw(screen)

                    levelLoader.goal.draw(screen)
                    if not paused:
                        levelLoader.char.loop()
                        levelLoader.char.draw(screen)
                        handle_move(levelLoader.char)
                        doorsFont = pygame.font.SysFont(None, 24)
                        doorsImg = doorsFont.render('Doors: ' + str(levelLoader.char.doors), True, (255,255,255))
                        screen.blit(doorsImg, (WIDTH - 100, HEIGHT - 40))

                        keysFont = pygame.font.SysFont(None, 24)
                        keysImg = keysFont.render('Keys: ' + str(levelLoader.char.keys), True, (255,255,255))
                        screen.blit(keysImg, (WIDTH - 200, HEIGHT - 40))

                        levelFont = pygame.font.SysFont(None, 24)
                        levelImg = levelFont.render('Level: ' + str(levelLoader.number), True, (255,255,255))
                        screen.blit(levelImg, (WIDTH - 300, HEIGHT - 40))

                    if paused:
                        resume.draw()
                        reset.draw()
                        levelselect.draw()
                        quit.draw()
                else:
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                            running = False
                        if event.type == pygame.MOUSEBUTTONDOWN:
                            if level1.checkForInput(MENU_MOUSE_POS):
                                levelLoader.loadlevel1()
                                levelMenu = False
                                paused = False
                            if level2.checkForInput(MENU_MOUSE_POS):
                                levelLoader.loadlevel2()
                                levelMenu = False
                                paused = False
                            if level3.checkForInput(MENU_MOUSE_POS):
                                levelLoader.loadlevel3()
                                levelMenu = False
                                paused = False
                            if level4.checkForInput(MENU_MOUSE_POS):
                                levelLoader.loadLevel4()
                                levelMenu = False
                                paused = False
                            if level5.checkForInput(MENU_MOUSE_POS):
                                levelLoader.loadLevel5()
                                levelMenu = False
                                paused = False
                            if exit.checkForInput(MENU_MOUSE_POS):
                                tutorial = False
                                mainMenu = True
                    level1.draw()
                    level2.draw()
                    level3.draw()
                    level4.draw()
                    level5.draw()
                    exit.draw()
            else:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        running = False
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        if levelselect.checkForInput(MENU_MOUSE_POS):
                            levelMenu = True
                            mainMenu = False
                        if howToPlay.checkForInput(MENU_MOUSE_POS):
                            levelMenu = False
                            mainMenu = False
                            tutorial = True
                levelselect.draw()
                title.draw()
                howToPlay.draw()
        else:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if exit.checkForInput(MENU_MOUSE_POS):
                        tutorial = False
                        mainMenu = True
            tutorialFont = pygame.font.SysFont(None, 32)
            tutorialImg = tutorialFont.render('WASD or arrows to move, Q to pause', True, (255,255,255))
            text_rect = tutorialImg.get_rect(center=(WIDTH/2, 100))
            screen.blit(tutorialImg, text_rect)

            tutorialFont = pygame.font.SysFont(None, 32)
            tutorialImg = tutorialFont.render('When in front of a wall press SPACE to create a door', True, (255,255,255))
            text_rect = tutorialImg.get_rect(center=(WIDTH/2, 200))
            screen.blit(tutorialImg, text_rect)

            tutorialFont = pygame.font.SysFont(None, 32)
            tutorialImg = tutorialFont.render('Collect the keys to lock the doors you create', True, (255,255,255))
            text_rect = tutorialImg.get_rect(center=(WIDTH/2, 300))
            screen.blit(tutorialImg, text_rect)

            tutorialFont = pygame.font.SysFont(None, 32)
            tutorialImg = tutorialFont.render('When in front of a door press E to lock the door', True, (255,255,255))
            text_rect = tutorialImg.get_rect(center=(WIDTH/2, 400))
            screen.blit(tutorialImg, text_rect)

            tutorialFont = pygame.font.SysFont(None, 32)
            tutorialImg = tutorialFont.render('When you lock a door, a door of the same colour will unlock', True, (255,255,255))
            text_rect = tutorialImg.get_rect(center=(WIDTH/2, 500))
            screen.blit(tutorialImg, text_rect)

            

            exit.draw()
        pygame.display.flip()
        dt = clock.tick(60) / 1000
        await asyncio.sleep(0)
    pygame.quit()


asyncio.run(main())